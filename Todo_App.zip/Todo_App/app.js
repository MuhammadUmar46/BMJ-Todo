const firebaseConfig = {
  apiKey: "AIzaSyAAqjgJOmLrFCnTTEBnN3fAikVwB2svO80",
  authDomain: "web-and-mob-4470e.firebaseapp.com",
  projectId: "web-and-mob-4470e",
  storageBucket: "web-and-mob-4470e.appspot.com",
  messagingSenderId: "1010185818848",
  appId: "1:1010185818848:web:63fcae5e049b0374683685",
  measurementId: "G-G34W038NMK",
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);

var list = document.getElementById("list");

firebase
  .database()
  .ref("todos")
  .on("child_added", function (data) {

    // Li tag
    var li = document.createElement("li");
    var liText = document.createTextNode(data.val().value);
    li.setAttribute("class", "liTag");
    li.appendChild(liText);

    // Create Button
    var delBtn = document.createElement("button");
    var delText = document.createTextNode("DELETE");
    delBtn.setAttribute("class", "delButton");
    delBtn.setAttribute('id',data.val().key)
    delBtn.setAttribute("onclick", "deleteItem(this)");
    delBtn.appendChild(delText);

    // Edit Button
    var editBtn = document.createElement("button");
    var editText = document.createTextNode("EDIT");
    editBtn.setAttribute("class", "editButton");
    editBtn.setAttribute('id',data.val().key)
    editBtn.setAttribute("onclick", "editItem(this)");
    editBtn.appendChild(editText);

    li.appendChild(delBtn);
    li.appendChild(editBtn);

    list.appendChild(li);
  })


function addTodo() {
  var todo_item = document.getElementById("todo-item");
  var database = firebase.database().ref("todos");
  var key = database.push().key;

  var todo = {
    value: todo_item.value,
    key: key,
  };
  database.child(key).set(todo);

  todo_item.value = "";
}


function deleteItem(e) {
  firebase.database().ref('todos').child(e.id).remove()
  e.parentNode.remove()
}


function editItem(e) {

  var val = prompt(
    "Enter Your Edited Value",
    e.parentNode.firstChild.nodeValue
  );
  var editTodo ={
    value : val,
    key : e.id
  }

  firebase.database().ref('todos').child(e.id).set(editTodo)
  e.parentNode.firstChild.nodeValue = val;
}


function deleteAll() {
  firebase.database().ref('todos').remove()
  list.innerHTML = "";
}
